#include "transport_catalogue.h"

void TransportCatalogue::AddStop(Stop&& stop) {
    stops_.emplace_back(std::move(stop));
    name_to_stops_.insert({std::string_view(stops_.back().stop_name_), &stops_.back()});
}

void TransportCatalogue::AddBus(Bus&& bus) {
    buses_.emplace_back(std::move(bus));
    name_to_buses_.insert({std::string_view(buses_.back().bus_name_), &buses_.back()});
    for(Stop* st : buses_.back().route_stops_) {
        st->buses_through_stop_.emplace(buses_.back().bus_name_);
    }
    if (bus.route_type_ != RouteType::ROUND) {
        for (int i = buses_.back().route_stops_.size() -2; i>=0; --i) {
            buses_.back().route_stops_.emplace_back(buses_.back().route_stops_[i]);
        }
    } else {
        buses_.back().route_stops_.emplace_back(buses_.back().route_stops_[0]);
    }
}

void TransportCatalogue::SetDistancesBetweenStops() {
    for (Stop& stop : stops_) {
        Stop* src_stop = GetStopByName(stop.stop_name_);
        for (const auto& [dest_name, dist] : stop.dist_to_stops_) {
            Stop* dest_stop = GetStopByName(dest_name);
            const StopsPair pair {src_stop, dest_stop};
            const StopsPair rev_pair {dest_stop, src_stop};
            if (distances_for_stops.count(pair) > 0) {
                distances_for_stops.at(pair) = dist;
            } else {
                distances_for_stops.insert({pair, dist});
            }
            if (!distances_for_stops.count(rev_pair)) {
                distances_for_stops.insert({rev_pair, dist});
            }
        }
    }
}

Stop* TransportCatalogue::GetStopByName(std::string_view stop_name) const {
    return name_to_stops_.count(stop_name) ? name_to_stops_.at(stop_name) : (std::nullptr_t)nullptr;
}

Bus* TransportCatalogue::GetBusByName(std::string_view bus_name) const {
    return name_to_buses_.count(bus_name) ? name_to_buses_.at(bus_name) : (std::nullptr_t)nullptr;
}

int TransportCatalogue::GetDistanceBetweenStops(Stop* from, Stop* to) const {
    StopsPair pair{from,to};
    return distances_for_stops.at(pair);
}

const std::vector<std::string> TransportCatalogue::GetRoutesForStop (const Stop* st_p) const {
    std::vector<std::string> res (st_p->buses_through_stop_.begin(), st_p->buses_through_stop_.end());
    std::sort(res.begin(), res.end());
                //std::unordered_set<const Bus*> result(res.begin(), res.end());
    return res;
}