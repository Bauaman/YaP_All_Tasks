#pragma once

#include <set>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>

#include "geo.h"

enum class RouteType {
    ROUND,
    NOT_ROUND
};

struct Stop {
    Stop() = default;
    Stop (const std::string stop_name, const geo::Coordinates& coord) :
        stop_name_(stop_name),
        coord_(coord)
    {}
    std::string stop_name_;
    geo::Coordinates coord_;
    /*size_t Hash() const {
        return std::hash<std::string>{}(stop_name_) + magic_*std::hash<double>{}(coord_.lat) +
            magic_*magic_*std::hash<double>{}(coord_.lng);
    }
    static const size_t magic_{31};*/
    std::unordered_set<std::string> buses_through_stop_;
    std::unordered_map<std::string, int> dist_to_stops_;
};

struct Bus {
    Bus() = default;
    Bus (const std::string bus_name, RouteType type) :
        bus_name_(bus_name),
        route_type_(type)
    {}
    size_t GetStopsCount() const;
    std::string bus_name_;
    std::vector<Stop*> route_stops_;
    RouteType route_type_ = RouteType::NOT_ROUND;
};

struct BusInfo {
    int request_id_;
    std::string bus_no_;
    int stops_count_ = 0;
    int unique_stops_count_ = 0;
    int route_length_ = 0;
    double route_geo_distance = 0.;
    double curvature = 0.;
};

//using StopsPair = std::pair<const Stop*, const Stop*>;

struct StopsPair {
	const Stop* stop_from;
	const Stop* stop_to;

	bool operator==(const StopsPair& other) const {
		return stop_from == other.stop_from && stop_to == other.stop_to;
	}
};

