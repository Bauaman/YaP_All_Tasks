#include "map_renderer.h"

std::vector<svg::Polyline> MapRenderer::GetRouteLines (std::map<std::string_view, const Bus*> buses, const SphereProjector& sp) const {
    std::vector<svg::Polyline> res;
    int num = 0;
    for (auto [bus_name, bus] : buses) {
        if (bus->route_stops_.size() == 0) {
            continue;
        }
        svg::Polyline route;
        for (auto& stop : bus->route_stops_) {
            route.AddPoint(sp(stop->coord_));
        }
        route.SetFillColor("none");
        route.SetStrokeColor(render_settings_.color_palette_[num]);
        route.SetStrokeWidth(render_settings_.line_width_);
        route.SetStrokeLineCap(svg::StrokeLineCap::ROUND);
        route.SetStrokeLineJoin(svg::StrokeLineJoin::ROUND);
        res.push_back(std::move(route));
        ++num;
        if (num == render_settings_.color_palette_.size()-1) {
            num = 0;
        }
    }
    return res;
}

/*svg::Document */ void MapRenderer::GetSVGDoc(std::map<std::string_view, const Bus*>& buses, std::ostream& out) {
    std::vector<geo::Coordinates> stops_coordinates;
    for (auto [bus_name, bus] : buses) {
        for (Stop* stop : bus->route_stops_) {
            stops_coordinates.push_back(stop->coord_);
        }
    }
    SphereProjector sp(stops_coordinates.begin(), 
                        stops_coordinates.end(), 
                        render_settings_.width_, 
                        render_settings_.heigth_, 
                        render_settings_.padding_);
    svg::Document doc;
    std::vector<svg::Polyline> lines = GetRouteLines(buses, sp);
    for (const auto line : lines) {
        doc.Add(line);
    }
    doc.Render(out);
    //return doc;
}
