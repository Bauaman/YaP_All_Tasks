#include "request_handler.h"
#include "json_reader.h"

void RequestHandler::LinkTransportCatalogue(TransportCatalogue& tc) {
    catalogue_ = &tc;
}

void RequestHandler::GetHandler() {
    handler_ = new JsonDataReader(catalogue_);
}

void RequestHandler::ProcessRequests(std::istream& input) {
    handler_->ProcessRequests(input);
}

void RequestHandler::ProcessStatRequests() {
    handler_->ProcessStatRequests();
}

void RequestHandler::PrintStatsJson(std::ostream& out) {
    handler_->PrintStatsAsJson(out);
}

void RequestHandler::GetMapRenderer() {
    renderer_ = new MapRenderer(handler_->ProcessRenderSettings());
}

void RequestHandler::RenderMap() {
    GetMapRenderer();
    svg::Document doc;
    std::map<std::string_view, const Bus*> buses = catalogue_->GetSortedBuses();
    doc = renderer_->GetSVGDoc(buses, std::cout);
    doc.Render(std::cout);   
}

